package org.simplilearn.flyaway.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int userID;

	private String userName;

	private String userPwd;

	private String userEmail;

	@ManyToOne
	@JoinColumn(name = "places_id")
	private Places placesID;
	
	@OneToMany(mappedBy ="user")
	private List<Booking> booking;
	
	
	public User() {
		// TODO Auto-generated constructor stub
	}

	public User(int userID, String userName, String userPwd, String userEmail, Places placesID, List<Booking> booking) {
		super();
		this.userID = userID;
		this.userName = userName;
		this.userPwd = userPwd;
		this.userEmail = userEmail;
		this.placesID = placesID;
		this.booking = booking;
		
	}

	public int getUserID() {
		return userID;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPwd() {
		return userPwd;
	}

	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public Places getPlacesID() {
		return placesID;
	}

	public void setPlacesID(Places placesID) {
		this.placesID = placesID;
	}

	public List<Booking> getBooking() {
		return booking;
	}

	public void setBooking(List<Booking> booking) {
		this.booking = booking;
	}

	public void addBooking(Booking booking) {
		this.booking.add(booking);
	}
	
	public void removeBoking(Booking booking) {
		this.booking.remove(booking);
		//booking.setUser(null);
	}
}

