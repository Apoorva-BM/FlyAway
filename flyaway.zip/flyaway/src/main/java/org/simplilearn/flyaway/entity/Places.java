package org.simplilearn.flyaway.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Places implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int placeId;
	
	private String placeName;
	
	@OneToMany(mappedBy = "placesID")
	private List<User> user;
	
	public Places() {
		// TODO Auto-generated constructor stub
	}

	public Places(int placeId, String placeName, List<User> user) {
		super();
		this.placeId = placeId;
		this.placeName = placeName;
		this.user = user;
	}
	
	@Override
	public String toString() {
		return placeName;
	}

	public int getPlaceId() {
		return placeId;
	}

	public void setPlaceId(int placeId) {
		this.placeId = placeId;
	}

	public String getPlaceName() {
		return placeName;
	}

	public void setPlaceName(String placeName) {
		this.placeName = placeName;
	}

	public List<User> getUser() {
		return user;
	}

	public void setUser(List<User> user) {
		this.user = user;
	}
	
	public void addUser(User user) {
		this.user.add(user);
	}
	
	public void removeUser(User user) {
		this.user.remove(user);
		//booking.setUser(null);
	}
}
