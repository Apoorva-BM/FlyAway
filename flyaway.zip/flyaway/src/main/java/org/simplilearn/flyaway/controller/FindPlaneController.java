package org.simplilearn.flyaway.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.simplilearn.flyaway.entity.Flight;
import org.simplilearn.flyaway.model.PlaceModel;
import org.simplilearn.flyaway.service.FlightService;
import org.simplilearn.flyaway.service.PlacesService;
import org.simplilearn.flyaway.service.impl.FlightServiceImpl;
import org.simplilearn.flyaway.service.impl.PlacesServiceImpl;

@WebServlet("/findPlane")
public class FindPlaneController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private PlacesService service =  new PlacesServiceImpl(); 
	private FlightService flightService = new FlightServiceImpl();

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		List<String> placeList = service.getPlaceList();
			HttpSession session=request.getSession();
			session.setAttribute("placeList", placeList);
		String selectedsrc = request.getParameter("selectedsrc");
		String selecteddest = request.getParameter("selecteddest");
		String flightDateInput = request.getParameter("flightDateInput");
		//String flightSeat = request.getParameter("flightSeat");
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		try {
		Date flightDate = dateFormat.parse(flightDateInput); 
		PlaceModel model = new  PlaceModel();
		model.setPlaceSrc(selectedsrc);
		model.setPlaceDest(selecteddest);
		model.setFlightDate(flightDate);
		//int seat = Integer.parseInt(flightSeat);
		//model.setFlightSeat(seat);
		List<Flight> availableFlights = flightService.getAvailableFlights(model);
		if(!availableFlights.isEmpty())
		{
			session.setAttribute("availableFlights", availableFlights);
			RequestDispatcher rd=request.getRequestDispatcher("booking.jsp");
			rd.forward(request, response);
		}
		else
		{
			request.setAttribute("msg", "No Flights Avaialble");
		}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		RequestDispatcher rd=request.getRequestDispatcher("home.jsp");
		rd.forward(request, response);

	}

}
