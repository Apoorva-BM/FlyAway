package org.simplilearn.flyaway.model;

import java.util.Date;

public class PlaceModel {

private String placeSrc;
private String placeDest;
private Date flightDate;
private  int flightSeat;
public PlaceModel() {
	// TODO Auto-generated constructor stub
}
public PlaceModel(String placeSrc, String placeDest, Date flightDate, int flightSeat) {
	super();
	this.placeSrc = placeSrc;
	this.placeDest = placeDest;
	this.flightDate = flightDate;
	this.flightSeat = flightSeat;
}
public String getPlaceSrc() {
	return placeSrc;
}
public void setPlaceSrc(String placeSrc) {
	this.placeSrc = placeSrc;
}
public String getPlaceDest() {
	return placeDest;
}
public void setPlaceDest(String placeDest) {
	this.placeDest = placeDest;
}
public Date getFlightDate() {
	return flightDate;
}
public void setFlightDate(Date flightDate) {
	this.flightDate = flightDate;
}
public int getFlightSeat() {
	return flightSeat;
}
public void setFlightSeat(int flightSeat) {
	this.flightSeat = flightSeat;
}

}
