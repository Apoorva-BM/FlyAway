package org.simplilearn.flyaway.service.impl;

import org.simplilearn.flyaway.dao.UserDao;
import org.simplilearn.flyaway.dao.impl.UserDaoImpl;
import org.simplilearn.flyaway.entity.User;
import org.simplilearn.flyaway.model.UserModel;
import org.simplilearn.flyaway.service.UserService;

public class UserServiceImpl implements UserService{

	private UserDao dao = new UserDaoImpl();
	
	@Override
	public void addUser(UserModel user) {
		User userEntity=new User();
		userEntity.setUserName(user.getUserName());
		userEntity.setUserPwd(user.getUserPwd());
		userEntity.setUserEmail(user.getUserEmail());
		dao.insertUser(userEntity);	
	}

	@Override
	public User getUser(String userName, String userPwd) {
		return dao.get(userName, userPwd);
	}

	@Override
	public User getPwdUser(String userName, String userEmail) {
		return dao.getPwd(userName,userEmail);
	}

	@Override
	public void changePwd(String userName, String userPwd) {
		dao.updatePwd(userName, userPwd);
	}

}
