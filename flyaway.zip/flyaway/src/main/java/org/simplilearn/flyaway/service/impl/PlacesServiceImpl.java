package org.simplilearn.flyaway.service.impl;

import java.util.List;

import org.simplilearn.flyaway.dao.PlacesDao;
import org.simplilearn.flyaway.dao.impl.PlacesDaoImpl;
import org.simplilearn.flyaway.service.PlacesService;

public class PlacesServiceImpl implements PlacesService{
private PlacesDao dao = new PlacesDaoImpl(); 
	@Override
	public List<String> getPlaceList() {
		return dao.getPlaceList();
	}

}
