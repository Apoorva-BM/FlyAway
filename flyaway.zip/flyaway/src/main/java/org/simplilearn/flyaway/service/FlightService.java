package org.simplilearn.flyaway.service;

import java.util.List;

import org.simplilearn.flyaway.entity.Flight;
import org.simplilearn.flyaway.model.PlaceModel;

public interface FlightService {
	List<Flight> getAvailableFlights(PlaceModel model);
}
