package org.simplilearn.flyaway.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.simplilearn.flyaway.config.HibConfig;
import org.simplilearn.flyaway.dao.PlacesDao;

public class PlacesDaoImpl implements PlacesDao{

	@Override
	public List<String> getPlaceList() {
		SessionFactory factory=HibConfig.getSessionFactory();
		Session session=factory.openSession();
		List<String> placeNames = new ArrayList<>();
		Query<String> query=null;
		try {
			factory=HibConfig.getSessionFactory();
			session=factory.openSession();
			String hql = "SELECT p.placeName FROM org.simplilearn.flyaway.entity.Places p";
		    query = session.createQuery(hql, String.class);
		    placeNames = query.list();
		    System.out.println("Place Names: " + placeNames);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return placeNames;
	}

	
}
