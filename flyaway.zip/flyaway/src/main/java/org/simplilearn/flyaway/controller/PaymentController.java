package org.simplilearn.flyaway.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.simplilearn.flyaway.model.PlaceModel;

@WebServlet("/processPayment")
public class PaymentController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String flightId = request.getParameter("flightId");
	    String cardNumber = request.getParameter("cardNumber");
	    String expirationDate = request.getParameter("expirationDate");
	    request.setAttribute("flightId", flightId);
	    request.setAttribute("cardNumber", cardNumber);
	    request.setAttribute("expirationDate", expirationDate);
	    PlaceModel model = new PlaceModel();
	    request.setAttribute("destination",model.getPlaceDest());
	    request.setAttribute("source",model.getPlaceSrc());
	    request.setAttribute("date", model.getFlightDate());
	    request.setAttribute("seat", model.getFlightSeat());
	    Boolean paymentProcessed = true;
	    request.setAttribute("paymentProcessed", paymentProcessed);
	    request.getRequestDispatcher("/payment.jsp").forward(request, response);
	}

}
