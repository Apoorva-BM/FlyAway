package org.simplilearn.flyaway.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.simplilearn.flyaway.entity.User;
import org.simplilearn.flyaway.model.UserModel;
import org.simplilearn.flyaway.service.UserService;
import org.simplilearn.flyaway.service.impl.UserServiceImpl;

@WebServlet("/changepwdnew")
public class NewPassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserService userService  = new UserServiceImpl();

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String newpassword =request.getParameter("newpassword");
		String username=request.getParameter("username");
		UserModel model = new UserModel();
		model.setUserPwd(newpassword);
		model.setUserName(username);
		userService.changePwd(username, newpassword);
			HttpSession session=request.getSession();
			RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
			rd.forward(request, response);
		
	}

}
