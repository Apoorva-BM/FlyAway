package org.simplilearn.flyaway.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.simplilearn.flyaway.model.PlaceModel;

@WebServlet("/booking")
public class BookingController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String flightId = request.getParameter("flightId");
		String seatId = request.getParameter("seat");
		int seats = Integer.parseInt(seatId);
		PlaceModel model = new  PlaceModel();
		model.setFlightSeat(seats);
		if(flightId != null) {
			 request.setAttribute("flightId", flightId);
			 request.getRequestDispatcher("/payment.jsp").forward(request, response);
		}else {
			RequestDispatcher rd=request.getRequestDispatcher("home.jsp");
			rd.forward(request, response);
		}
		
	}

}
