package org.simplilearn.flyaway.service;

import java.util.List;

public interface PlacesService {

	List<String> getPlaceList();
}
