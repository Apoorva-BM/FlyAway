package org.simplilearn.flyaway.dao;

import java.util.List;

public interface PlacesDao {

	List<String> getPlaceList();
}
