package org.simplilearn.flyaway.dao.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.simplilearn.flyaway.config.HibConfig;
import org.simplilearn.flyaway.dao.FlightDao;
import org.simplilearn.flyaway.entity.Flight;
import org.simplilearn.flyaway.entity.Places;

public class FlightDaoImpl implements FlightDao {

	@Override
	public List<Flight> getAvailableFlights(Places flightSrc,Places flightDest,Date flightDate) {
		SessionFactory factory=HibConfig.getSessionFactory();
		Session session=factory.openSession();
		List<Flight> flights = new ArrayList<>();
		Flight flight =null;
		Places place =null;
		Query<String> query=null;
		try {
			factory=HibConfig.getSessionFactory();
			session=factory.openSession();
			
		    flights = session.createQuery("FROM org.simplilearn.flyaway.entity.Flight f where f.flightSrc=?1 and f.flightDest=?2 and f.flightDate=?3", Flight.class)
	                .setParameter(1, flightSrc)
	                .setParameter(2, flightDest)
	                .setParameter(3, flightDate)
	                .getResultList();
		    System.out.println("flight details " + flights.indexOf(1));
		    System.out.println("flight details " + flightDate);
		    System.out.println("flight details " + flight.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flights;
	}

}
