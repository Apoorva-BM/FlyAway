package org.simplilearn.flyaway.entity;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Flight {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int flightId;
	
	private String flightName;
	
	private int flightSeat;
	
	private int flightPrice;
	
	@ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "flightSrc", referencedColumnName = "placeName")
	private Places flightSrc;
	
	@ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "flightDest",referencedColumnName = "placeName")
	private Places flightDest;
	
	private Date flightDate;
	
	private LocalDateTime flightArrival;
	
	private LocalDateTime flightDeparture;
	
	@ManyToOne
    @JoinColumn(name = "airline_id")
	private AirLine flightLine;
	
	@OneToMany(mappedBy = "flight")
	private List<Booking> booking;
	
	public Flight() {
		// TODO Auto-generated constructor stub
	}

	public Flight(int flightId, String flightName, int flightSeat, int flightPrice, Places flightSrc, Places flightDest,
			Date flightDate, LocalDateTime flightArrival, LocalDateTime flightDeparture, AirLine flightLine,
			List<Booking> booking) {
		super();
		this.flightId = flightId;
		this.flightName = flightName;
		this.flightSeat = flightSeat;
		this.flightPrice = flightPrice;
		this.flightSrc = flightSrc;
		this.flightDest = flightDest;
		this.flightDate = flightDate;
		this.flightArrival = flightArrival;
		this.flightDeparture = flightDeparture;
		this.flightLine = flightLine;
		this.booking = booking;
	}

	public int getFlightId() {
		return flightId;
	}

	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}

	public String getFlightName() {
		return flightName;
	}

	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}

	public int getFlightSeat() {
		return flightSeat;
	}

	public void setFlightSeat(int flightSeat) {
		this.flightSeat = flightSeat;
	}

	public int getFlightPrice() {
		return flightPrice;
	}

	public void setFlightPrice(int flightPrice) {
		this.flightPrice = flightPrice;
	}

	public Places getFlightSrc() {
		return flightSrc;
	}

	public void setFlightSrc(Places flightSrc) {
		this.flightSrc = flightSrc;
	}

	public Places getFlightDest() {
		return flightDest;
	}

	public void setFlightDest(Places flightDest) {
		this.flightDest = flightDest;
	}

	public Date getFlightDate() {
		return flightDate;
	}

	public void setFlightDate(Date flightDate) {
		this.flightDate = flightDate;
	}

	public LocalDateTime getFlightArrival() {
		return flightArrival;
	}

	public void setFlightArrival(LocalDateTime flightArrival) {
		this.flightArrival = flightArrival;
	}

	public LocalDateTime getFlightDeparture() {
		return flightDeparture;
	}

	public void setFlightDeparture(LocalDateTime flightDeparture) {
		this.flightDeparture = flightDeparture;
	}

	public AirLine getFlightLine() {
		return flightLine;
	}

	public void setFlightLine(AirLine flightLine) {
		this.flightLine = flightLine;
	}

	public List<Booking> getBooking() {
		return booking;
	}

	public void setBooking(List<Booking> booking) {
		this.booking = booking;
	}
	
	public void addBooking(Booking booking) {
		this.booking.add(booking);
	}
	
	public void removeBoking(Booking booking) {
		this.booking.remove(booking);
		//booking.setUser(null);
	}
	
	@Override
    public String toString() {
		return "Flights Detials:" +
        "flightId ="+ flightId +
		"flightName =" + flightName +
		"flightSeat =" + flightSeat +
		"flightPrice =" + flightPrice +
		"flightSrc = " + flightSrc +
		"flightDest = " + flightDest +
		"flightDate = " + flightDate +
		"flightArrival =" + flightArrival +
		"flightDeparture = " +  flightDeparture +
		"flightLine = " +  flightLine ;
	}
}
