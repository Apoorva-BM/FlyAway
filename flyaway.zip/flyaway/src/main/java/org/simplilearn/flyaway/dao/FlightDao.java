package org.simplilearn.flyaway.dao;

import java.util.Date;
import java.util.List;

import org.simplilearn.flyaway.entity.Flight;
import org.simplilearn.flyaway.entity.Places;

public interface FlightDao {
	List<Flight> getAvailableFlights(Places flightSrc,Places flightDest,Date flightDate);
}
