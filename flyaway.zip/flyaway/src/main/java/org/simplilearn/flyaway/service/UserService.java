package org.simplilearn.flyaway.service;

import org.simplilearn.flyaway.entity.User;
import org.simplilearn.flyaway.model.UserModel;

public interface UserService {

	void addUser(UserModel user);
	User getUser(String userName, String userPwd);
	User getPwdUser(String userName,String userEmail);
	void changePwd(String userName,String userPwd );
}
