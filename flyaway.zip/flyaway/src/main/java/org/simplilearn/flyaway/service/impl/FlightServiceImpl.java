package org.simplilearn.flyaway.service.impl;

import java.util.List;

import org.simplilearn.flyaway.dao.FlightDao;
import org.simplilearn.flyaway.dao.impl.FlightDaoImpl;
import org.simplilearn.flyaway.entity.Flight;
import org.simplilearn.flyaway.entity.Places;
import org.simplilearn.flyaway.model.PlaceModel;
import org.simplilearn.flyaway.service.FlightService;

public class FlightServiceImpl implements FlightService {
private FlightDao dao = new FlightDaoImpl();
	@Override
	public List<Flight> getAvailableFlights(PlaceModel model) {
		Places source = new Places();
		source.setPlaceName(model.getPlaceSrc());
		Places destination = new Places();
		destination.setPlaceName(model.getPlaceDest());
		 return dao.getAvailableFlights(source,destination,model.getFlightDate());
	}

}
